﻿using System;

namespace _2DArray_sum_all
{
    class Program
    {
        static void Main(string[] args)
        {
            int arr1Dim = 3, arr2Dim = 3, sum=0, product=1,average=0;
            Console.WriteLine("2D Array Sum");
            int[,] arr2D = new int[arr1Dim, arr2Dim];
            for (int index=0;index<arr1Dim;index++)
            {
                for (int subIndex=0;subIndex<arr2Dim;subIndex++)
                {
                    Console.Write("Enter ["+index+"]["+subIndex+"]: ");
                    arr2D[index, subIndex] = Convert.ToInt32(Console.ReadLine());
                    sum += arr2D[index, subIndex];
                    product *= arr2D[index, subIndex];
                }
            }
            for (int index = 0; index < arr1Dim; index++)
            {
                for (int subIndex = 0; subIndex < arr2Dim; subIndex++)
                {
                    Console.Write(arr2D[index, subIndex]+"\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine("\nSum Of all The Elements in The Given Matrix : "+sum);
            Console.WriteLine("\nProduct Of all The Elements in The Given Matrix : " + product);
            Console.WriteLine("\nAverage Of all The Elements in The Given Matrix : " + sum/(arr1Dim+arr2Dim));
        }
    }
}
