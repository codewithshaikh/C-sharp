﻿using System;

namespace While_PrimeNo_Checkl
{
    class Program
    {
        private static int n1;

        static void Main(string[] args)
        {
            Console.WriteLine("Prime Number Check............\t\t\tThis One doesn't have a Good Time Complexity");
            Console.Write("Enter Number: ");
            int number = Convert.ToInt32(Console.ReadLine());
            int n2 = 2;
            int n1 = 2;
            int result = 0;
            if (number % 2 == 0 && number>2)
            {
                Console.WriteLine("It's Not A Prime Number.....");
                return;
            }
            while (n1<=number)
            {
                while (result<=number)
                {
                    result = 0;
                    result = n1 * n2;
                    if (result==number)
                    {
                        Console.WriteLine("Not A Prime Number.....");
                        return;
                    }
                    n2++;
                    
                }
                n1++;
                
            }
            Console.WriteLine("Prime Number....");


        }
    }
}
