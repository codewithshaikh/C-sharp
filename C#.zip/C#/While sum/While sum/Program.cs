﻿using System;

namespace While_sum
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("While sum!");
            int sum = 0;
            int num = 1;
            while (num<11)
            {
                sum += num;
                Console.WriteLine(sum);
                num++;
            }
        }
    }
}
