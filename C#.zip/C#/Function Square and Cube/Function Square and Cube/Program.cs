﻿using System;

namespace Function_Square_and_Cube
{
    class Program
    {
        static int square(int no)
        {
            return no * no;
        }
        static int cube(int no)
        {
            return no * no*no;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(" Functions Square and Cube...");
            Console.Write("Enter Number: ");
            int no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Square : "+square(no)+"\tCube : "+cube(no));
        }
    }
}
