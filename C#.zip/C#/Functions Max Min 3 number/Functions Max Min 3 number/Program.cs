﻿using System;

namespace Functions_Max_Min_3_number
{
    class Program
    {
        static int max(int n1, int n2 , int n3)
        {
            int max = n1;
            if (n2>max)
            {
                max = n2;
            }
            if (n3>max)
            {
                max = n3;
            }
           
            return max;
        }
        static int min(int n1, int n2, int n3)
        {
            int min = n1;
            if (n2 < min)
            {
                min = n2;
            }
            if (n3 <min)
            {
                min = n3;
            }

            return min;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Functions Min Max 3 Number...");
            Console.Write("Enter 3 Numbers: ");
            int n1 = Convert.ToInt32(Console.ReadLine());
            int n2 = Convert.ToInt32(Console.ReadLine());
            int n3 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Min : " +min(n1, n2, n3)+"\t Max : "+max(n1, n2, n3));

        }
    }
}
