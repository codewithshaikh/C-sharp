﻿using System;

namespace Switch_Cal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculator....");
            Console.Write("Enter 1st Number::");
            int number1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd Number::");
            int number2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("1.\tAdd.");
            Console.WriteLine("2.\tMult.");
            Console.WriteLine("3.\tSub.");
            Console.WriteLine("4.\tDiv.");

            int opt = Convert.ToInt32(Console.ReadLine());

            switch (opt)
            {
                case 1:
                    Console.WriteLine("Add:"+number1+number2);
                    break;
                case 2:
                    Console.WriteLine("Multi:" + number1 * number2);
                    break;
                case 3:
                    Console.WriteLine("Sub:" + (number1 - number2));
                    break;
                case 4:
                    Console.WriteLine("Div:" + (number1 / number2));
                    break;
                default:
                    Console.WriteLine("Please Select Valid Option..");
                    break;
            }

        }
    }
}
