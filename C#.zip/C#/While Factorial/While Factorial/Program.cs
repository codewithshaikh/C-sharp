﻿using System;

namespace While_Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("While Factorial!");
            Console.Write("Enter Number To find Factorial ==>");
            int number = Convert.ToInt32(Console.ReadLine());
            int factorial = 1;
            while (number >0)
            {
                factorial *= number;
                number--;
            }
            Console.WriteLine("Factorial " + factorial);

        }
    }
}
