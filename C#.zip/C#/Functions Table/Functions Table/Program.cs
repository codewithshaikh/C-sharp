﻿using System;

namespace Functions_Table
{
    class Program
    {
        static void table(int no)
        {
            for (int n1=1;n1<=10;n1++)
            {
                Console.WriteLine(no+" X "+n1+" = "+(no*n1));
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Functions Tables..");
            Console.Write("Enter Number: ");
            int no = Convert.ToInt32(Console.ReadLine());
            table(no);
        }
    }
}
