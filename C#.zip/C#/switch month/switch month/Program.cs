﻿using System;

namespace switch_month
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number::");
            int number = Convert.ToInt32(Console.ReadLine());

            switch (number)
            {
                case 1:
                    Console.WriteLine("Jaunary");
                    break;
                case 2:
                    Console.WriteLine("Feb");
                    break;
                case 3:
                    Console.WriteLine("mar");
                    break;
                case 4:
                    Console.WriteLine("apr");
                    break;
                case 5:
                    Console.WriteLine("may");
                    break;
                case 6:
                    Console.WriteLine("Jun");
                    break;
                case 7:
                    Console.WriteLine("Jul");
                    break;
                case 8:
                    Console.WriteLine("aug");
                    break;
                case 9:
                    Console.WriteLine("Sep");
                    break;
                case 10:
                    Console.WriteLine("Oct");
                    break;
                case 11:
                    Console.WriteLine("nov");
                    break;
                case 12:
                    Console.WriteLine("Dec");
                    break;
                default:
                    Console.WriteLine("Please Enter Valid Number");
                    break;
            }
        }
    }
}
