﻿using System;

namespace _2D_Array_Read_Print
{
    class Program
    {
        static void Main(string[] args)
        {
            int arr1Dim = 3, arr2Dim = 3;
            Console.WriteLine("2D Array....");
            int[,] arr2D = new int[arr1Dim, arr2Dim];
            for (int index=0;index<arr1Dim;index++)
            {
                for (int subIndex=0;subIndex<arr2Dim;subIndex++)
                {
                    Console.Write("Enter ["+index+"]["+subIndex+"]: ");
                    arr2D[index,subIndex] = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                }
            }
            for (int index = 0; index < arr1Dim; index++)
            {
                for (int subIndex = 0; subIndex < arr2Dim; subIndex++)
                {
                    Console.Write(arr2D[index,subIndex]+"\t");
                }
                Console.WriteLine();
            }
        }
    }
}
