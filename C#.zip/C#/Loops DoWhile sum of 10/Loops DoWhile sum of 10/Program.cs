﻿using System;

namespace Loops_DoWhile_sum_of_10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Do While sum !");
            int sum = 0;
            int num = 0;
            do
            {
                sum += num;
                Console.WriteLine(sum);
                num++;
            } while (num <= 10);
        }
    }
}
