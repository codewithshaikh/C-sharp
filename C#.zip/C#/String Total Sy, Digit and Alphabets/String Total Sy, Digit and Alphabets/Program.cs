﻿using System;

namespace String_Total_Sy__Digit_and_Alphabets
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Total Alphabets Symbols and Digit...");
            Console.Write("Enter Text: ");
            String text = Console.ReadLine();
            int alpha = 0, digit = 0, Symbols=0;
            for (int index = 0; index < text.Length; index++)
            {
                if (text[index] != ' ')
                {
                    if ((text[index] >= 'a' && text[index] <= 'z') || (text[index]>='A' && text[index]<='Z') )
                    {
                        alpha++;
                    }
                    if ((text[index] >= '0' && text[index] <= '9'))
                    {
                        digit++;
                    }
                    if ((text[index] < '1' || text[index]>'9') && (text[index] < 'A' || text[index] > 'Z') && (text[index] < 'a' || text[index] > 'z'))
                        Symbols++;
                }
                
            }
            Console.WriteLine("Digits: " + digit + "\tSymbols: " + Symbols+"\tAlphabets: "+alpha);

        }
    }
}
