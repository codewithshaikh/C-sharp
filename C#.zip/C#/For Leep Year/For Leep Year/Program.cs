﻿using System;

namespace For_Leep_Year
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For Leep Year!");
            Console.WriteLine("Enter Limit: ");
            int limit = Convert.ToInt32(Console.ReadLine());
            
            for (int start = 2000;start <=(limit);start++)      //Yet to Develope............
            {
                
                if (start % 4 == 0)
                {
                    Console.WriteLine(start + " Is Leep Year...");
                }
                else
                {
                    Console.WriteLine(start + " Is Not Leep Year...");
                }
                if (start == 2050)
                {
                    return;
                }
            }
        }
    }
}
