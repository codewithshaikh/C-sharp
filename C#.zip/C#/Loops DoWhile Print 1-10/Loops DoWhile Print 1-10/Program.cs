﻿using System;

namespace Loops_DoWhile_Print_1_10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Print 1-10");

            int number = 0;
            do
            {
                Console.WriteLine(number);
                number++;
            } while (number<11);
        }
    }
}
