﻿using System;

namespace Loops_For_print_1_10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For Print 1-0!");
            for (int i = 1; i <11;i++)  {
                Console.WriteLine(i);
            }
        }
    }
}
