﻿using System;

namespace Basic_Mounth_if_else
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program to find Mounth by input number");

            Console.Write("Enter Mounth No:");
            int dayNo = Convert.ToInt32(Console.ReadLine());

            if (dayNo == 1)
            {
                Console.WriteLine("January...");
            }
            if (dayNo == 2)
            {
                Console.WriteLine("February...");
            }
            if (dayNo == 3)
            {
                Console.WriteLine("March...");
            }
            if (dayNo == 4)
            {
                Console.WriteLine("April...");
            }
            if (dayNo == 5)
            {
                Console.WriteLine("May...");
            }
            if (dayNo == 6)
            {
                Console.WriteLine("June...");
            }
            if (dayNo == 7)
            {
                Console.WriteLine("August...");
            }
            if (dayNo == 8)
            {
                Console.WriteLine("September...");
            }
            if (dayNo == 9)
            {
                Console.WriteLine("October...");
            }
            if (dayNo == 10)
            {
                Console.WriteLine("November...");
            }
            if (dayNo == 12)
            {
                Console.WriteLine("December...");
            }
            if (dayNo > 12 || dayNo == null)
            {
                Console.WriteLine("Please Enter valid Number...");
            }
        }
    }
}
