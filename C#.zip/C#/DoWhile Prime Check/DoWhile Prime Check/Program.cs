﻿using System;

namespace DoWhile_Prime_Check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Do While Prime Check....!");

            Console.Write("Enter Number: ");
            int number = Convert.ToInt32(Console.ReadLine());
            int count = 0,n=1;
            while (n<=number )
            {
                if (number % n == 0)
                {
                    count++;
                }
                n++;
            }
            if (count == 2)
            {
                Console.WriteLine("It's a Prime Number.... ");
            }
            else
            {
                Console.WriteLine("Not A Prime Number..");
            }
        }
    }
}
