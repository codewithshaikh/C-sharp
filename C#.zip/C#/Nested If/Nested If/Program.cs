﻿using System;

namespace Nested_If
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grade!");

            Console.Write("Enter physics Marks::");
            int mark1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Chemistry Marks::");
            int mark2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Biology Marks::");
            int mark3 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Maths Marks::");
            int mark4 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Computer Marks::");
            int mark5 = Convert.ToInt32(Console.ReadLine());

            int total = mark1 + mark2 + mark3 + mark4 + mark5;
            int percential = total * 100 /500;

            if (percential < 35)
            {
                Console.WriteLine("Failed");
            }
            else
            {
                if (percential > 95)
                {
                    Console.WriteLine("A+");
                }else if (percential > 90 && percential <95)
                {
                    Console.WriteLine("A");
                }else if(percential >80 && percential <90)
                {
                    Console.WriteLine("B");
                }else if (percential > 60 && percential <80)
                {
                    Console.WriteLine("C");
                }else if (percential > 50 && percential <60 )
                {
                    Console.WriteLine("D");
                }else if (percential > 35 && percential <50)
                {
                    Console.WriteLine("Passed");
                }else if (percential <35)
                {
                    Console.WriteLine("Failed");
                }
            }
           


        }
    }
}
