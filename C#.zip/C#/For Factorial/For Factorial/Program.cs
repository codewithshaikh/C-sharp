﻿using System;

namespace For_Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For Factorial!");
            Console.Write("Enter Number To find Factorial ==>");
            int number = Convert.ToInt32(Console.ReadLine());
            int factorial = 1;
            for (; number>0;number--)
            {
                factorial *= number;
            }
            Console.WriteLine("Factorial : "+factorial);
        }
    }
}
