﻿using System;

namespace Basic_if_else_check_Maximum_btw3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program to find maxium between 2 number");
            Console.Write("Enter Number::");
            int number1 = Convert.ToInt32(Console.ReadLine());
            int number2 = Convert.ToInt32(Console.ReadLine());
            int number3 = Convert.ToInt32(Console.ReadLine());
            int max=number1;
            if (number2 > number2)
            {
                max = number2;
            }
            if (number3>max)
            {
                max = number3;
            }
            Console.WriteLine("Maximum : "+max);
        }
    }
}
