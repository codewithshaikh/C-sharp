﻿using System;

namespace Loops_DoWhile__evenOdd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("DoWhile Even Odd!");
            Console.Write("Enter Limit:: ");
            int limit = Convert.ToInt32(Console.ReadLine());
            int number = 1;
            do
            {
                if (number%2==0)
                {
                    Console.WriteLine(number +" Is Even");
                }
                else
                {
                    Console.WriteLine(number + " Is Odd");
                }
                number++;
            } while (number<limit);
        }
    }
}
