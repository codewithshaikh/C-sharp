﻿using System;

namespace DoWhile_Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("DoWhile Factorial!");
            Console.Write("Enter Number To find Factorial ==>");
            int number = Convert.ToInt32(Console.ReadLine());
            int factorial = 1;
            do
            {
                factorial *= number;
                number--;
            } while (number > 0);
            Console.WriteLine("Factorial : "+factorial );
        }
    }
}
