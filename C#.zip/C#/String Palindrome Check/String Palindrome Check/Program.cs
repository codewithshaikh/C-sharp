﻿using System;

namespace String_Palindrome_Check
{
    class Program
    {
        static void Main(string[] args)
        {
            string text, reverseText = "";
            Console.WriteLine("String Palindrome Check....");
            Console.Write("Enter Text: ");
            text = Console.ReadLine();
            for(int index=text.Length-1;index>=0;index--)
            {
                reverseText += text[index];
            }
            if (text.Equals(reverseText))
            {
                Console.WriteLine("Its Palindrome...");
            }
            else
            {
                Console.WriteLine("Not a Palindrome..");
            }
        }
    }
}
