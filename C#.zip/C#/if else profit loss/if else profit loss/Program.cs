﻿using System;

namespace if_else_profit_loss
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Profit Loss Interest!");

            Console.Write("Enter  Cost Pice:");
            int costPrice = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Selling price: ");
            int sellingPrice = Convert.ToInt32(Console.ReadLine());

            if (sellingPrice >costPrice)
            {
                Console.WriteLine("Profit");
            }
            if (sellingPrice < costPrice)
            {
                Console.WriteLine("Loss");
            }
        }
    }
}
