﻿
using System;

namespace DoWhile_Tables
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("DoWhile Tables!");
            Console.Write("Enter Number  to show table: ");
            int number = Convert.ToInt32(Console.ReadLine());

            int times = 1;
            do
            {
                Console.WriteLine(number + " X " + times + " = " + (number * times));
                times++;
            } while (times<=10);
        }
    }
}
