﻿using System;

namespace String_Reverse_String
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String Reverse..");
            Console.Write("Enter text: ");
            string text = Console.ReadLine();
            for (int index=text.Length-1; index>=0;index--)
            {
                Console.Write(text[index]);
            }
        }
    }
}
