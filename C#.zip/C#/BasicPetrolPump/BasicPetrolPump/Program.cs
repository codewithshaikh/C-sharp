﻿using System;

namespace BasicPetrolPump
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program to find Price of petrol for how much you want to travel using milage of your Vechical and price of petrol/liter..");

            Console.Write("Enter Petrol price:");
            int pertrolPrice = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Average: ");
            int average = Convert.ToInt32(Console.ReadLine());

            int perLiter = pertrolPrice / average;
            Console.WriteLine("Cost per liter =>"+perLiter+ " per liter");

            Console.Write("Enter Traving Distance :");
            int distance = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Total price : "+ (perLiter*distance));
        }
    }
}
