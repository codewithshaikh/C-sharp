﻿using System;

namespace functins_Fact_even
{
    class Program
    {
        static int fact(int no)
        {
            
            int i = no, fac=1;
            while (i>0)
            {
                fac *= i;
                i--;
            }
            return fac;
        }
        static bool evenCheck(int no)
        {
            if (no % 2 == 0)
                return true;
            return false;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Functions  Even Odds Factorials");
            int no = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Factorial : "+fact(no)+"\tIs Even: "+evenCheck(no));

        }
    }
}
