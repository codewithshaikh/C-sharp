﻿using System;

namespace String_Upper_to_Lower
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String Upper to Lower vise verse....");
            Console.Write("Enter String : ");
            string text = Console.ReadLine();

            Console.WriteLine("To Uppercase: "+text.ToUpper());
            Console.WriteLine("To Lower: " + text.ToLower());

        }
    }
}
