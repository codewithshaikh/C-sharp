﻿using System;

namespace String_Toggle_Case
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String Toggle Case");
            Console.Write("Enter String: ");
            String text = Console.ReadLine();

            for (int index=0;index<text.Length;index++)
            {
                if (text[index] >= 'a' && text[index]<='z')
                {
                    Console.Write((char)(text[index] - 32));

                }
                if (text[index] >= 'A' && text[index]<='Z')
                {
                    Console.Write((char)(text[index] + 32));
                }
                
            }
        }
    }
}
