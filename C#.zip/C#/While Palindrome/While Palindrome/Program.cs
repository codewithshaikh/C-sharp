﻿using System;

namespace While_Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("While Palindrome Number....");
            Console.Write("Enter Number: ");
            int number = Convert.ToInt32(Console.ReadLine());
            int reverseNumber = 0;
            int no = number;
            while (no>0)
            {
                reverseNumber *= 10;
                reverseNumber += no % 10;
                no /= 10;
            }
            if (number==reverseNumber)
            {
                Console.WriteLine("This Number is Palindrome...");
            }
            else
            {
                Console.WriteLine("This Number is Not a Palindrome...");
            }
        }
    }
}
