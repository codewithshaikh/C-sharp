﻿using System;

namespace Functions_Reverse_Number
{
    class Program
    {
        static int sum(int no)
        {
            int sum = 0;
            for (int i=0;i<=no;i++)
            {
                sum += i;
            }
            return sum;
        }
        static int reverse(int rev)
        {
            int reverse = 0,n1=rev;
            while (reverse<=rev)
            {
                reverse *= 10;
                reverse += n1%10;
                n1 /= 10;

            }
            return reverse;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Functions Reverse Number......");
            Console.Write("Enter No: ");
            int no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Reverse: "+reverse(no)+"\tSum : "+sum(no));
        }
    }
}
