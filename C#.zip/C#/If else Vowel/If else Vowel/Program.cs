﻿using System;

namespace If_else_Vowel
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vowel check");

            Console.Write("Enter Char: ");
            int ch= Convert.ToChar(Console.ReadLine());
            if (ch=='a'|| ch == 'e'|| ch == 'i'|| ch == 'o' || ch == 'u' )
            {
                Console.WriteLine("Vowel");
            }
            else
            {
                Console.WriteLine("Consonant");
            }
        }
    }
}
