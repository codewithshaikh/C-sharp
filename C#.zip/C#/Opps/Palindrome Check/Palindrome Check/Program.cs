﻿using System;

namespace Palindrome_Check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Palindrome Check...........");
            PalindromeDemo obj = new PalindromeDemo();
            obj.getValues();
            obj.Display();
        }
        class PalindromeDemo
        {
            private int number = 0;
            
            public void getValues()
            {
                Console.Write("Enter Limit: ");
                number = Convert.ToInt32(Console.ReadLine());
            }
            public void Display()
            {
                int i = 10;
                while (i<number)
                {
                    Console.WriteLine(i+ " is palindrome : "+isPalindrome(i));
                    i++;
                }
            }
            private bool isPalindrome(int n)
            {
                int reverseNumber = 0;

                for (int no = n; no > 0;)
                {
                    reverseNumber *= 10;
                    reverseNumber += no % 10;
                    no /= 10;
                }
                if (n == reverseNumber )
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            
        }
    }
}
