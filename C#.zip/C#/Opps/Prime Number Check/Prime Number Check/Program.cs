﻿using System;

namespace Prime_Number_Check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Prime Number Check....");
            PrimeDemo obj = new PrimeDemo();
            obj.getValues();
            obj.checkRange();
        }
    }
    class PrimeDemo
    {
        private int no = 0,number = 0;
        public void getValues()
        {
            Console.Write("Enter Range: ");
            no = Convert.ToInt32(Console.ReadLine());
        }
        private bool isPrime(int number)
        {
            int count = 0, n = 1;
            while (n <= number)
            {
                if (number % n == 0)
                {
                    count++;
                }
                n++;
            }
            if (count == 2)
            {
                return true;
            }

            return false;
        }
        public void checkRange()
        {
            int nm = 1;
            while (nm < no) {
                if(isPrime(nm))
                Console.WriteLine(nm );
                nm++;
            }

        }
    }
}
