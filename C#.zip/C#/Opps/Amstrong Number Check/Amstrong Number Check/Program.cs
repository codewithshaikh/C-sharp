﻿using System;

namespace Amstrong_Number_Check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Armstrong Number......");
            ArmStrongDemo obj = new ArmStrongDemo();
            obj.getValues();
            obj.display();
        }
        class ArmStrongDemo
        {
            private int no=0, result = 0;
            private int digit;

            public void getValues()
            {
                Console.Write("Enter Number: ");
                no = Convert.ToInt32(Console.ReadLine());
            }
            private int getCube(int no) { return no * no * no; }
            private int armstrongCheck()
            {
                int number = no;
                while ( number> 0)
                {
                    digit =number% 10;
                    result += getCube(digit);
                    number /= 10;
                    digit = 0;
                }
                return result;
            }
            private bool isArmstrong()
            {
                armstrongCheck();
                if (result==no)
                    return true;
                else return false;
            }
            public void display()
            {
                Console.WriteLine("Number is Armstrong: "+isArmstrong());
            }
        }
    }
}
