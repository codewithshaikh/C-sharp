﻿using System;

namespace Prime_Check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Prime Check....");
            Number obj = new Number();
            obj.getValues();
            obj.display();
        }

        class Number
        {
            private int number=0;
            public void getValues()
            {
                Console.Write("Enter Number: ");
                number = Convert.ToInt32(Console.ReadLine());
            }
            private bool isPrime()
            {
                int count = 0, n = 1;
                while (n <= number)
                {
                    if (number % n == 0)
                    {
                        count++;
                    }
                    n++;
                }
                if (count == 2)
                {
                    return true;
                }
                
                return false;
            }
            public void display()
            {
                Console.WriteLine("Is Prime: "+isPrime());
            }
        }
    }
}
