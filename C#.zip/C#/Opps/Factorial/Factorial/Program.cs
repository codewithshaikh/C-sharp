﻿using System;

namespace Factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Factorials....");
            FactDemo obj = new FactDemo();
            obj.getValues();
            obj.display();
        }
    }
    class FactDemo
    {
        private int no=0;
        public void getValues()
        {
            Console.Write("Enter Number: ");
            no = Convert.ToInt32(Console.ReadLine());
        }
        public int getFactorial()
        {
            int result = 1;
            while (no>0)
            {
                result *= no;
                no--;
            }
           
            return result;
        }
        public void display()
        {
            Console.WriteLine("Factorial of Given Number: "+getFactorial());
        }
    }
}
