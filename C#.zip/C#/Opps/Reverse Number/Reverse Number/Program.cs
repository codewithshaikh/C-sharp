﻿using System;

namespace Reverse_Number
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Reverse Number............");
            ReversCls obj = new ReversCls();
            obj.getValues();
            obj.display();
        }
        class ReversCls
        {
            private int no=0, reverse=0;
            public void getValues()
            {
                Console.Write("Enter number: ");
                no = Convert.ToInt32(Console.ReadLine());
            }
            private int getReverseNumber()
            {
                int number=no;
                while (reverse<no)
                {
                    reverse *= 10;
                    reverse += number % 10;
                    number /= 10;
                }
                return reverse;
            }
            public void display()
            {
                Console.WriteLine("Reverse: "+getReverseNumber());
            }
        }
    }
}
