﻿
using System;

namespace Addition
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Addition Using OPPs");
            Addition add1 = new Addition();
            add1.getData();
            add1.display();
        }
    }
    class Addition
    {
        private int N1=0, N2=0;
        public void getData()
        {
            Console.Write("Enter 2 Numbers: ");
            N1 = Convert.ToInt32(Console.ReadLine());
            N2 = Convert.ToInt32(Console.ReadLine());
        }
        public int add()
        {
            return N1 + N2;
        }
        public void display()
        {
            Console.WriteLine("Addition: "+ add());
        }
    }
}
