﻿using System;

namespace Fibonacci
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Fibonacci Series........");
            FiboDemo obj = new FiboDemo();
            obj.getValues();
            obj.display();
        }
    }
    class FiboDemo
    {
        private int no = 0, result = 0;
        public void getValues()
        {
            Console.Write("Enter Number: ");
            no = Convert.ToInt32(Console.ReadLine());
        }
        private int getFibonicci(int fiNo)
        {

            if (fiNo == 0)
            {
                return result;
            }
            result += fiNo;
            fiNo--;
            return getFibonicci(fiNo);
        }
        public void display()
        {
            Console.WriteLine("Fibonocci : "+getFibonicci(no));
        }
    }
}
