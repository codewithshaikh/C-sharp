﻿using System;

namespace String_Length
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String Length....");
            Console.Write("Enter String: ");
            string text = Console.ReadLine();

            Console.WriteLine("Length Of Given String: "+text.Length);
        }
    }
}
