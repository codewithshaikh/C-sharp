﻿using System;

namespace DoWhile_Palidrome
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("DoWhile Palindrome Number....");
            Console.Write("Enter Number: ");
            int number = Convert.ToInt32(Console.ReadLine());
            int reverseNumber = 0;
            int no = number;
            do
            {
                reverseNumber *= 10;
                reverseNumber += no % 10;
                no /= 10;

            } while (no > 0);
            if (number == reverseNumber)
            {
                Console.WriteLine("This Number is Palindrome...");
            }
            else
            {
                Console.WriteLine("This Number is Not a Palindrome...");
            }
        }
    }
}
