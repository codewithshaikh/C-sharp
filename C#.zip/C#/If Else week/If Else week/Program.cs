﻿using System;

namespace If_Else_week
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Program to find Day by input number");

            Console.Write("Enter Day No:");
            int dayNo = Convert.ToInt32(Console.ReadLine());

            if (dayNo==1)
            {
                Console.WriteLine("Today is Sunday...");
            }
            if (dayNo == 2)
            {
                Console.WriteLine("Today is Monday...");
            }
            if (dayNo ==3)
            {
                Console.WriteLine("Today is Tuesday...");
            }
            if (dayNo == 4)
            {
                Console.WriteLine("Today is Wednesday...");
            }
            if (dayNo == 5)
            {
                Console.WriteLine("Today is Thursday...");
            }
            if (dayNo == 6)
            {
                Console.WriteLine("Today is Friday...");
            }
            if (dayNo == 7)
            {
                Console.WriteLine("Today is Saturday...");
            }
            if(dayNo >7 || dayNo==null)
            {
                Console.WriteLine("Please Enter valid Number...");
            }
        }
    }
}
