﻿using System;

namespace _2D_Array_addition
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("2D Array Addition....");
            int arr1Dim = 3, arr2Dim = 3;
            int[,] OneArr2D = new int[arr1Dim, arr2Dim];
            int[,] TwoArr2D = new int[arr1Dim, arr2Dim];
            Console.WriteLine("---------------------------1St Matrix-----------------------------");
            for (int index=0; index<arr1Dim;index++)
            {
                for (int subIndex=0;subIndex<arr2Dim;subIndex++)
                {
                    Console.Write("Elemet ["+index+"]["+subIndex+"]: ");
                    OneArr2D[index, subIndex] = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                }
            }
            Console.WriteLine("---------------------------2nd Matrix-----------------------------");
            for (int index = 0; index < arr1Dim; index++)
            {
                for (int subIndex = 0; subIndex < arr2Dim; subIndex++)
                {
                    Console.Write("Elemet [" + index + "][" + subIndex + "]: ");
                    TwoArr2D[index, subIndex] = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                }
            }
            Console.WriteLine("---------------------------Resultant Matrix-----------------------------");
            for (int index = 0; index < arr1Dim; index++)
            {
                for (int subIndex = 0; subIndex < arr2Dim; subIndex++)
                {
                    Console.Write(OneArr2D[index, subIndex] + TwoArr2D[index, subIndex]+"\t");
                }
                Console.WriteLine();
            }
        }
    }
}
