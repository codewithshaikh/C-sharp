﻿using System;

namespace String_Consonants_and_Vowels
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String Consonants Vowels....");
            Console.Write("Enter Text:");
            string text = Console.ReadLine();
            int consonants = 0, vowels = 0;
            text.ToLower();
            for (int index = 0; index < text.Length; index++)
            {
                if (text[index] != ' ')
                {
                    if (text[index] == 'a' || text[index] == 'e' || text[index] == 'i' || text[index] == 'o' || text[index] == 'u')
                    {
                        vowels++;
                    }
                    else
                    {
                        consonants++;
                    }
                }
            }
            Console.WriteLine("Total Consonants: "+consonants+"\t Vowels: "+vowels); 
        }
    }
}
