﻿using System;

namespace Loops_While_Print_1_10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("While Print 1-10!");
            int number = 0;
            while (number < 11)
            {
                Console.WriteLine(number);
                number++;
            }
        }
    }
}
