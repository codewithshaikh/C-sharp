﻿using System;

namespace Word_Search
{
    class Program
    {
        static int search(string searchWord, string sentenc)
        {
            string[] words=sentenc.Split(" ");
            for (int index=0;index<words.Length;index++)
            {
                if(words[index].Equals(searchWord))
                {
                    return index;
                }
            }
            return 0;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Word Search");

            Console.Write("Enter Sentence: ");
            string text = Console.ReadLine();
            Console.Write("\nEnter Word to search: ");
            string searchText = Console.ReadLine();
            Console.WriteLine("Word Position : "+search(searchText,text));
        }
    }
}
