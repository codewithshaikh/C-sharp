﻿using System;

namespace for_sum
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For sum !");
            int sum = 0;
            for (int i=1;i<11;i++)
            {
                sum += i;
                Console.WriteLine(sum);
            }

        }
    }
}
