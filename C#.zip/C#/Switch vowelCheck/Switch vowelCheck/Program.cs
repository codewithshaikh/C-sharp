﻿using System;

namespace Switch_vowelCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vowel Check With Switch!");


            Console.WriteLine("Enter Letter:");
            int ch = Convert.ToChar(Console.ReadLine().ToLower());
            
            switch (ch)
            {
                case  'a':
                    Console.WriteLine("Vowel..");
                    break;

                case 'i':
                    Console.WriteLine("Vowel..");
                    break;

                case 'o':
                    Console.WriteLine("Vowel..");
                    break;

                case 'e':
                    Console.WriteLine("Vowel..");
                    break;

                case 'u':
                    Console.WriteLine("Vowel..");
                    break;
                default:
                    Console.WriteLine("Consonant....");
                    break;
            }

        }
    }
}
