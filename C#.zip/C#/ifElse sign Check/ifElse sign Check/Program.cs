﻿using System;

namespace ifElse_sign_Check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program to check dsign of number");

            Console.Write("Enter Number:");
            int number = Convert.ToInt32(Console.ReadLine());
            if (number >0)
            {
                Console.WriteLine("+Ve");
            }
            if (number < 0)
            {
                Console.WriteLine("-Ve");
            }
            if(number == 0){
                Console.WriteLine("Zero");
            }
            
        }
    }
}
