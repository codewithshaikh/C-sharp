﻿using System;

namespace String_Concatenate
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Strig Concatente...");
            Console.Write("Enter String 1: ");
            string text1 = Console.ReadLine();
            Console.Write("Enter String 1: ");
            string text2 = Console.ReadLine();
            Console.WriteLine("Concatenate String: "+text1+text2);
        }
    }
}
