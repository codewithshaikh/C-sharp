﻿using System;

namespace Array_Max_Min
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Array Min Max...");
            int Min = 0,Max=0;
            int[] arr = new int[4];
            for (int index=0; index<arr.Length;index++)
            {
                Console.Write("Enter Number: ");
                arr[index]= Convert.ToInt32(Console.ReadLine());
            }
            for (int index = 0; index < arr.Length; index++)
            {
                if (arr[index]>Max)
                {
                    Max = arr[index];
                    Min = Max;
                }
                if (arr[index]<Min)
                {
                    Min = arr[index];
                }
            }
            Console.WriteLine("Min: "+Min+"\tMax: "+Max);
        }
    }
}
