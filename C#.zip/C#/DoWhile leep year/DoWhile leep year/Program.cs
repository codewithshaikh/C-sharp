﻿using System;

namespace DoWhile_leep_year
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("DoWhile Leep Year!");
            Console.WriteLine("Enter Limit: ");
            int limit= Convert.ToInt32(Console.ReadLine());
            int start = 2000;
            do
            {
                if (start%4==0)
                {
                    Console.WriteLine(start+" Is Leep Year...");
                }
                else
                {
                    Console.WriteLine(start + " Is Not Leep Year...");
                }
                start++;
            } while (start< limit && start <=2030);
        }
    }
}
