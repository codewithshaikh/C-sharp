﻿using System;

namespace String_words
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String Words....");
            Console.Write("Enter sentence: ");
            string text = Console.ReadLine();
            int words = 1;
            for (int index=0;index<text.Length; index++)
            {
                if (text[index]==' ')
                {
                    words++;
                }
            }
            Console.WriteLine("Total Numbers of Words: "+words); 

        }
    }
}
