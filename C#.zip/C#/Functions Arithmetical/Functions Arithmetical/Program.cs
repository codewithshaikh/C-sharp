﻿using System;

namespace Functions_Arithmetical
{
    class Program
    {
        static int add(int n1, int n2)
        {
            return n1 + n2;
        }
        static int sub( int n1, int n2)
        {
            return n1 - n2;
        }
        static int div(int n1, int n2)
        {
            return n1 / n2;
        }
        static int multi(int n1, int n2)
        {
            return n1*n2;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Functions Arithmetic ");
            Console.Write("Enter Number1 : ");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number2 : ");
            int n2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Addition: "+add(n1, n2)+"\t Sub: "+sub(n1, n2)+"\tDiv: "+div(n1, n2)+"\tMulti: "+multi(n1, n2));
        }
    }
}
