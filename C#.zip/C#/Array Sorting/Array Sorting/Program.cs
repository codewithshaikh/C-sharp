﻿using System;

namespace Array_Sorting
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Array Sorting.....");
            Console.Write("Enter Limit: ");
            int limit = Convert.ToInt32(Console.ReadLine());
            //long[] arr = new long[limit];
            //for (int index=0;index<arr.Length;index++)
            //{
            //    Console.Write("Enter Number: ");
            //    arr[index] = Convert.ToInt64(Console.ReadLine());
            //}
            //Console.WriteLine();
            //for (int index = 0; index < arr.Length; index++)
            //{
            //    Console.Write("Number: "+arr[index]+"\n");
            //}
            //Console.WriteLine("Limit of Array arr is "+arr.Length);


            int[] arr = new int[limit];
            for (int index = 0; index < arr.Length; index++)
            {
                Console.Write("Enter Number: ");
                arr[index] = Convert.ToInt32(Console.ReadLine());
            }
            int tem = 0;
            for (int index=0; index<arr.Length;index++)
            {
                //Console.WriteLine("Array At Index  :::: " + index);
                for (int i=index+1;i<arr.Length;i++)
                {
                    if (arr[index] > arr[i])
                    {
                        tem = arr[index];
                        arr[index] = arr[i];
                        arr[i] = tem;
                       
                    }
                }
            }
            for (int index = 0; index < arr.Length; index++)
            {
                Console.Write("Number: "+arr[index]+"\n");
                
            }
        }
    }
}
