﻿using System;

namespace Array_Read_Write
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Array user Input & print ..");
            string[] arr = new string[4];
            for (int index=0; index<arr.Length; index++)
            {
                Console.Write("Enter Name: ");
                arr[index] = Console.ReadLine();
                
            }

            for (int index = 0; index <arr.Length; index++)
            {
                Console.WriteLine("|\tName :\t"+arr[index]+"\t\t|");
            }

        }
    }
}
