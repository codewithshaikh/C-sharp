﻿using System;

namespace _2D_Array_Subtraction
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("2D Array Sum of Column....");
            int arr1Dim = 2, arr2Dim = 2, columnSum=0;
            int[,] arr = new int[arr1Dim, arr2Dim];
            for (int index = 0; index < arr1Dim; index++)
            {
                for (int subIndex = 0; subIndex < arr2Dim; subIndex++)
                {
                    Console.Write("Elemet [" + index + "][" + subIndex + "]: ");
                    arr[index, subIndex] = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                    ///Yet to Implement....
                }
            }
            for (int index = 0; index < arr1Dim; index++)
            {
                for (int subIndex = 0; subIndex < arr2Dim; subIndex++)
                {
                    Console.Write(arr[index, subIndex]+"\t");
                }
                Console.WriteLine();
            }
            for (int index = 0; index < arr1Dim; index++)
            {
                columnSum = 0;
                for (int index2 = 0; index2< arr2Dim; index2++)
                {
                    columnSum+=(arr[index2, index]);
                }
                Console.Write("\t"+columnSum);
            }
        }
    }
}
