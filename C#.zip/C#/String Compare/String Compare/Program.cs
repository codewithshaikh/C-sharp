﻿using System;

namespace String_Compare
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("String Compare...");
            Console.Write("Enter String 1: ");
            string text1 = Console.ReadLine();
            Console.Write("Enter String 2: ");
            string text2 = Console.ReadLine();
            if (text1.CompareTo(text2).Equals(0))
                Console.WriteLine("Strings Are Same...");
            else
                Console.WriteLine("Not Same..");

        }
    }
}
