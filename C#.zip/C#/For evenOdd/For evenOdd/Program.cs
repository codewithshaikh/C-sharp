﻿using System;

namespace For_evenOdd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For Even Odd!");
            Console.Write("Enter Limit:: ");
            int limit = Convert.ToInt32(Console.ReadLine());

            for (int number=1; number<limit;number++)
            {
                if (number % 2 == 0)
                {
                    Console.WriteLine(number + " Is Even");
                }
                else
                {
                    Console.WriteLine(number + " Is Odd");
                }
            }
        }
    }
}
