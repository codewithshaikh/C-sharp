﻿using System;

namespace If_else_Case_check
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Case Check Program!");
            Console.WriteLine("Enter Letter:");
            int ch = Convert.ToChar(Console.ReadLine());

            if ((Int32)ch > 64 && (Int32)ch<90)
            {
                Console.WriteLine("Capital");
            }
            if ((Int32)ch > 90)
            {
                Console.WriteLine("Small");
            }
            
        }
    }
}
