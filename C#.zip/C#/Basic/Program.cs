﻿using System;

namespace Basic
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Write  a Program to perform additon, subtraction, multiplicatin, division...");


            Console.WriteLine("Enter 1st number : ");
            int number1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter 2nd number : ");
            int number2 = Convert.ToInt32(Console.ReadLine());

            //int answer = number1 + number2;
            Console.WriteLine("1st Number: "+number1 + "\n2nd Number:"+number2 + "\n\n");
            Console.WriteLine("Addition ::"+(number1 + number2));
            Console.WriteLine("subtraction ::" + (number1 - number2));
            Console.WriteLine("multiplicatin ::" + (number1 * number2));
            Console.WriteLine("division ::" + (number1 / number2));
        }
    }
}
