﻿using System;

namespace BasicAreaOfCircle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Write a program to find area of circle, square, triangle, rectangle");

            Console.WriteLine("Enter Radius of Circle : ");
            int radius = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Area of circle:: "+(3.142 * radius));

            Console.WriteLine("Enter Length: ");
            int lenghtRectangle = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Breath: ");
            int breathRectangle = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Area of Rectangle:: " + (lenghtRectangle * breathRectangle));

            Console.WriteLine("Enter Side of Square : ");
            int side = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Area of circle:: " + Math.Pow(side, 2));

            Console.WriteLine("Enter Base: ");
            int baseT = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Height: ");
            int heightT = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Area of Triangle:: " + (0.5*baseT*heightT ));

        }
    }
}
