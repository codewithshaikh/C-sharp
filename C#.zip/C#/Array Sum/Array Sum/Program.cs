﻿using System;

namespace Array_Sum
{
    class Program
    {
       
        static void Main(string[] args)
        {
            Console.WriteLine("Array Sum...");
            int[] arr = new int[4];
            int sum = 0;
            for (int index=0; index<arr.Length;index++)
            {
                Console.Write("Enter Number: ");
                arr[index] = Convert.ToInt32(Console.ReadLine());
            }
            
            for (int index = 0; index < arr.Length; index++)
            {
                sum+=arr[index];
            }
            Console.WriteLine("\t\tSum Of Elements: "+sum);
        }
    }
}
