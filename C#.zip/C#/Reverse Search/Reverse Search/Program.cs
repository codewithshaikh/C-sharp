﻿using System;

namespace Array_Value_Change
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program to Change Vlaue in Array.......");

            Console.Write("Enter Length Of Array: ");
            int limit = Convert.ToInt32(Console.ReadLine());

            int[] arr = new int[limit];

            for (int index=0;index<arr.Length;index++)
            {
                Console.Write("Enter element [" + (index + 1) + "] :" );
                arr[index] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
            }
            for (int index = 0; index < arr.Length; index++)
            {
                Console.WriteLine("Element [" + (index + 1) + "] : " + arr[index]);
            }
            Console.WriteLine("Enter Index Value To Change: ");
            int valueIndex = Convert.ToInt32(Console.ReadLine());
            Console.Write("Current Value ("+arr[valueIndex-1]+") : ");
            int updateValue = Convert.ToInt32(Console.ReadLine());
            arr[valueIndex-1] = updateValue;
            for (int index = 0; index < arr.Length; index++)
            {
                Console.WriteLine("Element ["+(index+1)+"] : "+arr[index]);
            }
        }
    }
}
