﻿using System;

namespace BasicSquareAndCubic
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program to find square and cube of a given Number....");

            Console.Write("Enter Number:");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Square :: "+ (number*number)+"\nCube ::"+(number*number*number));
        }
    }
}
