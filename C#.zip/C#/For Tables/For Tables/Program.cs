﻿using System;

namespace For_Tables
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("For Table!");
            Console.Write("Enter Number  to show table: ");
            int number = Convert.ToInt32(Console.ReadLine());
            
            for (int times=1;times<=10; times++)
            {
                Console.WriteLine(number+" X "+times+" = "+(number*times));

            }
        }
    }
}
