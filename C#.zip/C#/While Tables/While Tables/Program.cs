﻿using System;

namespace While_Tables
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("While Tables!");
            Console.Write("Enter Number  to show table: ");
            int number = Convert.ToInt32(Console.ReadLine());
            int times = 1;
            while (times<=10)
            {
                Console.WriteLine(number + " X " + times + " = " + (number * times));
                times++;
            }
        }
    }
}
